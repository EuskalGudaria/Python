for i in range(3):
  print("rentrer un nombre : ")
  x = float(input())
  resultat = 3*(x*x) + (5*x) + 1
  print(round(resultat,2))