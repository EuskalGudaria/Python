print("rentrer un nombre : ")
x = int(input())
somme = x
for i in  range(x) :
  somme += i
print(somme)
