liste = [1,2,3,5,7,2]
somme = 0
for i in liste:
  somme += i
print (somme)