for x in range (10) :
  for y in range (40) :
    if (x+y) % 2 == 0 :
      print("X",end="")
    else :
      print("  ",end="")  
      
  print("")      