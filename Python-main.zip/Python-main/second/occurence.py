liste = [0,5,8,0,5,4,4,0,0,5,0]
for i in range(10):
  if i in liste :
    print("nombre d'occurence de : ",i ," = ", liste.count(i))
